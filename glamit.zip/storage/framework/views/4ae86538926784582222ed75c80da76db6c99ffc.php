<?php $__env->startSection('content'); ?>
    <p>ordenes de compra</p>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\glamit\resources\views/orders.blade.php ENDPATH**/ ?>