<?php $__env->startSection('content'); ?>
<div class="container">

        <div class="text-center">
                <?php switch($order->estado->id):
                    case (App\Estado::ESTADO_PENDIENTE): ?>
                    <?php case (App\Estado::ESTADO_AYUDA): ?>
                        <form action="/orders/<?php echo e($order->id); ?>/status" method="POST"> <?php echo method_field('PATCH'); ?> <?php echo csrf_field(); ?>  
                            <p class="text-primary">Esperando confirmacion de pago</p>
                            <button type="submit" name="status" value="<?php echo e(App\Estado::ESTADO_CANCELADO); ?>" class="btn btn-block bg-danger text-white">Cancelar el pedido</button>
                        </form>
                        <?php break; ?>
                    <?php case (App\Estado::ESTADO_CANCELADO): ?>
                        <p class="text-danger">PEDIDO CANCELADO</p>
                        <?php break; ?>
                    <?php case (App\Estado::ESTADO_APROBADO): ?>
                        <form action="/orders/<?php echo e($order->id); ?>/status" method="POST"> <?php echo method_field('PATCH'); ?> <?php echo csrf_field(); ?>  
                            <button type="submit" name="status" value="<?php echo e(App\Estado::ESTADO_PREPARANDO); ?>" class="btn btn-block bg-info text-white">Generar etiqueta de envio</button>
                        </form>
                        <?php break; ?>
                    <?php case (App\Estado::ESTADO_PREPARANDO): ?>
                        <form action="/orders/<?php echo e($order->id); ?>/status" method="POST"> <?php echo method_field('PATCH'); ?> <?php echo csrf_field(); ?>  
                            <button type="submit" name="status" value="<?php echo e(App\Estado::ESTADO_DESPACHADO); ?>" class="btn btn-block bg-info text-white">Despachar producto</button>
                        </form>
                        <?php break; ?>
                    <?php case (App\Estado::ESTADO_DESPACHADO): ?>
                        <p class="text-danger">El pedido ya ha sido despachado.</p>
                        <?php break; ?>
                    <?php case (App\Estado::ESTADO_ENTREGADO): ?>
                        <p class="text-success">El pedido ya ha sido entregado.</p>
                        <?php break; ?>
                    <?php case (App\Estado::ESTADO_RECLAMO): ?>
                        <p class="text-danger">Se ha iniciado un reclamo.</p>
                        <form action="/orders/<?php echo e($order->id); ?>/status" method="POST"> <?php echo method_field('PATCH'); ?> <?php echo csrf_field(); ?>  
                            <button type="submit" name="status" value="<?php echo e(App\Estado::ESTADO_CAMBIO); ?>" class="btn btn-lg bg-warning text-white">Enviar cambio de paquete</button>
                            <button type="submit" name="status" value="<?php echo e(App\Estado::ESTADO_CAMBIO); ?>" class="btn btn-lg bg-danger text-white">Enviar devolucion de dinero</button>
                        </form>
                        <?php break; ?>
                    <?php case (App\Estado::ESTADO_CAMBIO): ?>
                        <p class="text-danger">El producto ha sido cambiado.</p>
                        <?php break; ?>
                    <?php case (App\Estado::ESTADO_DEVOLUCION): ?>
                        <p class="text-danger">Se ha devuelto el dinero al usuario.</p>
                        <?php break; ?>
                <?php endswitch; ?>
            </div>

    <div class="card">
        <h5 class="card-header"><?php echo e($order->estado->estado); ?> - <?php echo e($order->estado->subestado); ?></h5>
        <div class="row">
            <div class="card-body col-6">
                <p>Item comprado: <strong><?php echo e($order->item_nombre); ?></strong></p>
                <p>Precio unitario: <strong>$<?php echo e(round($order->item_preciounitario)); ?></strong></p>
                <p>Cantidad: <strong><?php echo e($order->item_cantidad); ?></strong></p>
                <p>Fecha de creacion: <strong><?php echo e($order->fecha_creacion); ?></strong></p>
                <p>Ultima actualizacion: <strong><?php echo e($order->fecha_actualizacion); ?></strong></p>
                <?php if($order->fecha_factura): ?>
                <p>Fecha de factura: <strong><?php echo e($order->fecha_factura); ?></strong></p>
                <?php endif; ?>
            </div>
            <div class="card-body col-6">
                <p>Total de intereses: <strong>$<?php echo e(round($order->intereses)); ?></strong></p>
                <p>Subtotal: <strong>$<?php echo e($order->item_subtotal); ?></strong></p>
                <?php if($order->costo_envio): ?>
                <p>Costo de envio: <strong>$<?php echo e(round($order->costo_envio)); ?></strong></p>
                <p>Total: <strong>$<?php echo e(round($order->total)); ?></strong></p>
                <p>Tienda: <strong><?php echo e($order->tienda); ?></strong></p>
                <p>Metodo de envio: <strong><?php echo e($order->metodo_envio); ?></strong></p>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <div class="card mt-1">
        <h5 class="card-header">Datos del usuario</h5>
        <div class="card-body">
            <p>Nombre: <strong><?php echo e($order->cliente_nombre); ?></strong></p>
            <p>Email: <strong><?php echo e($order->cliente_email); ?></strong></p>
            <p>Telefono: <strong><?php echo e($order->cliente_telefono); ?></strong></p>
            <p>Direccion: <strong><?php echo e($order->cliente_direccion); ?></strong></p>
        </div>
    </div>
    
    
    
    
    
</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\glamit\resources\views/orders/show.blade.php ENDPATH**/ ?>