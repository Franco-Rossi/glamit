<?php $__env->startSection('content'); ?>

<table>
    <tr>
      <th>Nombre</th>
      <th>Item</th> 
      <th>Cantidad</th>
      <th>SubTotal</th>
      <th>Estado</th>
      <th>Ultima actualizacion</th>
      <th></th>
    </tr>
    <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td><?php echo e($order->cliente_nombre); ?></td>
        <td><?php echo e($order->item_nombre); ?></td> 
        <td><?php echo e($order->item_cantidad); ?></td>
        <td>$<?php echo e($order->item_subtotal); ?></td>
        <td><?php echo e($order->estado->estado); ?> - <?php echo e($order->estado->subestado); ?></td>
        <td><?php echo e($order->fecha_actualizacion); ?></td>
        <td><a href="/orders/<?php echo e($order->id); ?>">Ver compra</a></td> 
      </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </table>

  <div class="mt-2"><?php echo e($orders->links()); ?></div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\glamit\resources\views/orders/index.blade.php ENDPATH**/ ?>