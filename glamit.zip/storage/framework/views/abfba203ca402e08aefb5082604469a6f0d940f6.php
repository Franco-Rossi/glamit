<?php $__env->startSection('content'); ?>
<div class="row text-center justify-content-center">
    <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    
    <div class="col-4 mt-2">
        <div class="card h-100">
            <div class="card-header font-weight-bold"><?php echo e($order->item_nombre); ?></div>
            <div class="card-body">
                <p class="bg-info rounded-pill text-white"><strong><?php echo e($order->estado->estado); ?></strong> - <?php echo e($order->estado->subestado); ?></p>
                <h4 class="card-title"><?php echo e($order->item_cantidad); ?> unidades</h4>
                <h4 class="card-text">$<?php echo e($order->item_subtotal); ?></h4>
                
                <?php switch($order->estado->id):
                    case (App\Estado::ESTADO_PENDIENTE): ?>
                        <form action="/orders/<?php echo e($order->id); ?>/status" method="POST"> <?php echo method_field('PATCH'); ?> <?php echo csrf_field(); ?>  
                            <a name="" id="" class="btn btn-primary" href="/orders/pay/<?php echo e($order->id); ?>" role="button">Confirmar pago</a>
                            <button type="submit" name="status" value="<?php echo e(App\Estado::ESTADO_CANCELADO); ?>" class="btn btn-secondary">Cancelar pedido</button>
                            <button type="submit" name="status" value="<?php echo e(App\Estado::ESTADO_AYUDA); ?>" class="btn btn-info">Necesito ayuda</button>
                        </form>
                        <?php break; ?>
                    <?php case (App\Estado::ESTADO_AYUDA): ?>
                        <form action="/orders/<?php echo e($order->id); ?>/status" method="POST"> <?php echo method_field('PATCH'); ?> <?php echo csrf_field(); ?>  
                            <a name="" id="" class="btn btn-primary" href="/orders/pay/<?php echo e($order->id); ?>" role="button">Confirmar pago</a>
                            <button type="submit" name="status" value="<?php echo e(App\Estado::ESTADO_CANCELADO); ?>" class="btn btn-secondary">Cancelar pedido</button>
                        </form>
                        <?php break; ?>
                    <?php case (App\Estado::ESTADO_CANCELADO): ?>
                        <p class="text-danger">PEDIDO CANCELADO</p>
                        <?php break; ?>
                    <?php case (App\Estado::ESTADO_APROBADO): ?>
                        <p class="text-success">El pedido esta siendo preparado.</p>
                        <form action="/orders/<?php echo e($order->id); ?>/status" method="POST"> <?php echo method_field('PATCH'); ?> <?php echo csrf_field(); ?>  
                            <button type="submit" name="status" value="<?php echo e(App\Estado::ESTADO_RECLAMO); ?>" class="btn btn-danger">Hacer un reclamo</button>
                        </form>
                        <?php break; ?>
                    <?php case (App\Estado::ESTADO_PREPARANDO): ?>
                        <p class="text-success">El pedido esta siendo despachado.</p>
                        <form action="/orders/<?php echo e($order->id); ?>/status" method="POST"> <?php echo method_field('PATCH'); ?> <?php echo csrf_field(); ?>  
                            <button type="submit" name="status" value="<?php echo e(App\Estado::ESTADO_RECLAMO); ?>" class="btn btn-danger">Hacer un reclamo</button>
                        </form>
                        <?php break; ?>
                    <?php case (App\Estado::ESTADO_DESPACHADO): ?>
                        <p class="text-success">El pedido ya ha sido despachado.</p>
                        <form action="/orders/<?php echo e($order->id); ?>/status" method="POST"> <?php echo method_field('PATCH'); ?> <?php echo csrf_field(); ?>  
                            <button type="submit" name="status" value="<?php echo e(App\Estado::ESTADO_RECLAMO); ?>" class="btn btn-danger">Hacer un reclamo</button>
                            <button type="submit" name="status" value="<?php echo e(App\Estado::ESTADO_ENTREGADO); ?>" class="btn btn-success">Ya recibí mi producto</button>
                        </form>
                        <?php break; ?>
                    <?php case (App\Estado::ESTADO_ENTREGADO): ?>
                        <p class="text-success">El pedido ya ha sido entregado.</p>
                        <form action="/orders/<?php echo e($order->id); ?>/status" method="POST"> <?php echo method_field('PATCH'); ?> <?php echo csrf_field(); ?>  
                            <button type="submit" name="status" value="<?php echo e(App\Estado::ESTADO_RECLAMO); ?>" class="btn btn-danger">Hacer un reclamo</button>
                        </form>
                        <?php break; ?>
                    <?php case (App\Estado::ESTADO_RECLAMO): ?>
                        <p class="text-danger">Se ha iniciado un reclamo.</p>
                        <?php break; ?>
                    <?php case (App\Estado::ESTADO_CAMBIO): ?>
                        <p class="text-danger">Se está tramitando el cambio del producto.</p>
                        <?php break; ?>
                    <?php case (App\Estado::ESTADO_DEVOLUCION): ?>
                        <p class="text-danger">El dinero ha sido devuelto por el vendedor.</p>
                        <?php break; ?>
                <?php endswitch; ?>
                
            </div>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    
</div>
<div class="mt-2"><?php echo e($orders->links()); ?></div>





<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\glamit\resources\views/home.blade.php ENDPATH**/ ?>